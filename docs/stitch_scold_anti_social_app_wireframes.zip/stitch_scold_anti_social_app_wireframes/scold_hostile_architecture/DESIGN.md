---
name: Scold Hostile Architecture
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f21'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#e7bdb7'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#ad8883'
  outline-variant: '#5d3f3b'
  surface-tint: '#ffb4aa'
  primary: '#ffb4aa'
  on-primary: '#690003'
  primary-container: '#ff5545'
  on-primary-container: '#5c0002'
  inverse-primary: '#c0000a'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#c2c6d3'
  on-tertiary: '#2b313a'
  tertiary-container: '#8c919d'
  on-tertiary-container: '#252a34'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad5'
  primary-fixed-dim: '#ffb4aa'
  on-primary-fixed: '#410001'
  on-primary-fixed-variant: '#930005'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#dee2ef'
  tertiary-fixed-dim: '#c2c6d3'
  on-tertiary-fixed: '#161c25'
  on-tertiary-fixed-variant: '#424751'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  display-lg:
    fontFamily: Space Mono
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Space Mono
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Mono
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Mono
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.1em
spacing:
  gutter: 0.75rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
This design system establishes an unapologetic, anti-engagement UI paradigm rooted in visceral technical utilitarianism and institutional brutalism. Instead of seductive, friction-free dopamine loops, the interface introduces deliberate cognitive resistance, architectural rigidity, and clinical accountability.

### Target Audience & Psychological Posture
Designed for digital minimalists, technologists, and individuals seeking severe behavioral interruption against screen addiction. The emotional tone must evoke precision containment, institutional authority, and tactile tension. Surfaces feel unyielding—akin to military telemetry terminals, industrial test equipment, and clinical containment software.

### Visual Philosophy
- **Intentional Friction:** High-stakes interactive states, physical cognitive lockouts, and explicit countdown mechanics replace mindless taps.
- **Architectural Brutalism:** Precision 1px grid structures, mechanical division lines, zero ambient blur, and raw structural metadata.
- **Refined Industrial Polish:** While aggressive and unaccommodating, surfaces reject amateurish noise in favor of razor-sharp alignment, balanced optical rhythm, tabular data density, and calculated technical typography.

## Colors
The palette balances severe tactical restraint with high-visibility signal interventions. Every color serves an operational directive: ambient structural canvas, informational metadata, or critical punitive intervention.

### Dark Mode (Primary Engine)
- **Base Canvas:** Deep obsidian (`#0A0A0C`), providing an absolute void for hostile overlays.
- **Structural Surfaces:** Matte carbon tiered panels (`#121316` for containers, `#1C1E24` for elevated telemetry modules).
- **Ink & Typography:** Technical chalk white (`#EDEDF0`) for raw legibility; muted industrial zinc (`#8F94A0`) for low-tier system telemetry, timestamps, and architectural markers.
- **Signal Accents:** Surgical crimson/vermilion (`#FF3B30` / `#D32F2F`) signaling threshold violations, behavioral penalties, and active lockouts. Precision amber (`#F59E0B`) functions as intermediate telemetry warnings and degradation countdowns.
- **Borders:** Industrial edge carbon (`#2A2E39`) and active wireframe zinc (`#3F4452`).

### Light Mode (Clinical Inversion)
- **Base Canvas:** Architectural bleached paper (`#F8F9FA`).
- **Structural Surfaces:** Clinical concrete (`#F1F3F5` for primary modules, `#E9ECEF` for recess boundaries).
- **Ink & Typography:** Sharp technical ink (`#111318`) paired with muted carbon structure (`#5A6072`).
- **Signal Accents:** High-noon signal red (`#D32F2F`) and industrial safety orange (`#E65100`) to pierce sterile white backdrops without sacrificing optical weight.
- **Borders:** Crisp technical graphite (`#D0D5DD` base, `#111318` active structural boundary).

## Typography
Typography is structural and uncompromising. All elements are typeset using monospaced geometry to enforce optical cadence, tabular alignment, and institutional discipline.

### Type Hierarchy & System Behaviors
- **Display & Headlines (`Space Mono`):** Designed for aggressive state notifications, lock timers, and stark punitive verdicts. Letter-spacing remains tight to preserve industrial density.
- **Body & Functional Running Copy (`JetBrains Mono`):** Delivers clean horizontal grid tracking, distinct character shapes (preventing glyph ambiguity), and comfortable legibility despite technical density.
- **Labels & System Telemetry (`JetBrains Mono`):** Always transformed to uppercase with positive letter tracking (`0.06em` to `0.1em`). Used for indexing, memory readouts, active status codes, and terminal breadcrumbs.
- **Tabular Numerics:** All numerals must execute with `font-variant-numeric: tabular-nums` to ensure countdown digits and dynamic usage timers render without horizontal jitter.

## Layout & Spacing
The layout operates on a strict mechanical grid with uniform edge margins and explicit section dividing walls.

### Grid Dynamics
- **Mobile Paradigm:** 4-column fluid layout with an edge perimeter margin of `1rem` (`16px`) and interior gutters of `0.75rem` (`12px`). Every component snaps squarely to column boundaries.
- **Reflow & Modular Walls:** Components rarely use empty whitespace buffers to establish separation; structural separation is driven by continuous 1px hairline rules, segmented cell frames, and crosshair corner junctions (`+` or `L` markers).
- **Density Control:** Micro-paddings (`space-xs`, `space-sm`) govern internal terminal chips, status arrays, and input slots. Large spacing (`space-xl`) is reserved solely for cognitive pauses—isolating lockout warnings and disciplinary timers from peripheral interactions.

## Elevation & Depth
This design system categorically rejects soft atmospheric shadows, drop blurs, and skeuomorphic gradients. Depth is established through tectonic planar layering, hard-edged offsets, and technical line contrast.

### Tonal Stratification
- **Recessed Inset (Level -1):** Ground zero `#0A0A0C` (or `#F1F3F5` in light mode), bordered with inset 1px lines to signify passive terminal slots or logged-out domains.
- **Base Surface (Level 0):** Structural canvas panels (`#121316` / `#F8F9FA`) forming the operational foundation.
- **Raised Tectonic Plate (Level 1):** elevated cards and active control bays (`#1C1E24` / `#E9ECEF`), outlined by 1px solid boundaries (`#2A2E39` / `#D0D5DD`).

### Hard-Offset Tactical Projection
Interactive elements and urgent notifications achieve spatial prominence not through blurred drop shadows, but through raw 2px or 4px solid color offsets:
- **Shadow Construct:** `box-shadow: 2px 2px 0px 0px #FF3B30` or `box-shadow: 3px 3px 0px 0px #000000`.
- **Interactive State Displacement:** On active tap or press, the element physically shifts (`translate(2px, 2px)`), zeroing out the solid shadow block to mimic mechanical switches.

## Shapes
Geometry is strictly unyielding. The shape index is set to `0` (Sharp). 

### Edge Rules
- Radii are default `0px` across buttons, inputs, modals, cards, badges, and notification panes.
- Corner geometry rejects circular rounding to enforce the hostile, anti-ergonomic tone.
- In edge-case micro-indicators (such as real-time tracking pips), square 4px blocks or 45-degree chamfered geometry are utilized instead of rounded pills.

## Components

### Buttons & Intentional Friction Controls
- **Primary Punitive Button:** Sharp 0px corners, filled vermilion background (`#FF3B30`), high-contrast ink text (`#0A0A0C`), bold monospace labels. Hover/active applies an inverted border with a `2px 2px 0px #EDEDF0` solid offset.
- **Hold-to-Confirm Barrier (Cognitive Lockout):** Friction-heavy interaction requiring a continuous 3.0s press to break through a distraction lockout. Styled with a segmented hairline progress track filling from left to right in solid safety amber (`#F59E0B`). Releasing before completion abruptly snaps progress to zero with a haptic failure pulse.
- **Ghost System Action:** 1px wireframe border (`#3F4452`), transparent background, chalk white text. Pressed state triggers full background inversion.

### Cards & Telemetry Modules
- Built on matte carbon (`#121316`), wrapped in a 1px solid border (`#2A2E39`).
- Features a compulsory **Header Rail**: a 24px tall strip with an indexed module number (`MODULE_01 // SEC_LIMIT`), an active terminal state pill, and a hairline divider splitting the header from the content bay.

### Status Badges & Tactical Chips
- Ultra-dense rectangular containers (`padding: 2px 6px`).
- Monospaced `label-sm` font, always uppercase.
- Status states:
  - *BREACH / PUNITIVE:* Red solid border, translucent red tint, stark red text.
  - *RESTRICTED:* Amber solid border, amber text.
  - *CONTAINED:* Zinc solid border, muted industrial zinc text.

### Form Fields & Input Slots
- Flat rectangular slots, completely devoid of rounded styling.
- 1px border (`#2A2E39`) that snaps to pure technical white (`#EDEDF0`) or alert crimson (`#FF3B30`) upon focus.
- Monospace input caret with high-frequency mechanical blink (non-eased). Includes absolute prefix labels (e.g., `LIMIT_HRS: [ 02 ]`).

### Checkboxes & Segmented Radios
- Hard 14px square bounding boxes (0px border radius).
- Unchecked: 1px wireframe outline.
- Checked: Filled solid vermilion or stark white with an internal solid black square block (or crosshair `×`), discarding conventional organic checkmark glyphs.

### Punitive Lockout Overlay (Hostile Intervention Component)
- Full-screen obstruction window masking the host application.
- Raw obsidian background (`#0A0A0C`) stamped with high-contrast perimeter caution striping (CSS diagonal linear-gradient: alternating `#FF3B30` and `#0A0A0C` stripes at 12px intervals).
- Center module hosts a massive non-dismissible tabular countdown clock (`display-lg`), real-time infraction diagnostics, and explicit refusal of standard gesture dismissal (swipes, escape keys, and back gestures are intercepted and denied).